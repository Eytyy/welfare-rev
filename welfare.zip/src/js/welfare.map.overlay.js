const OVERLAY = (shell) => {
  return {
    init() {
      shell.listen({
        'map-is-loaded': this.createOverlay,
      });
    },

    destroy() {
    },

    createOverlay(map) {
      const bounds = new google.maps.LatLngBounds(
        new google.maps.LatLng(31.77278, 35.225652),
        new google.maps.LatLng(31.783742, 35.237573)
      );

      const overlayImg = '../images/basemap.png';

      // Overlay constructor function
      function WELFAREOverlay(image) {
        // initialize all properties.
        this.bounds = bounds;
        this.image = image;
        this.map = map;

        // Define a property to hold the image's div. We'll
        // actually create this div upon recipt of the onAdd()
        // method so we'll leav it null for now.
        this.div = null;

        // Explicitly call setMap on this overlay.
        this.setMap(map);
      }

      WELFAREOverlay.prototype = new google.maps.OverlayView();

      /*
      onAdd is called when the map's panes are ready and the overlay has been
      added to the map
      */
      WELFAREOverlay.prototype.onAdd = function() {
        const div = document.createElement('div');
        div.style.borderStyle = 'none';
        div.style.borderWidth = '0px';
        div.style.position = 'absolute';

        // Create the img element and attach it to the div.
        const img = document.createElement('img');
        img.src = this.image;
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.position = 'absolute';
        div.appendChild(img);

        this.div = div;

        // Add the element to the 'overlayLayer' pane.
        const panes = this.getPanes();
        panes.overlayLayer.appendChild(div);
      };

      WELFAREOverlay.prototype.draw = function() {
        // We use the south-west and north-east coordinates
        // of the overlay to peg it to the correct position and size.
        // To do this, we need to retrieve the projection from the overlay.
        const overlayProjection = this.getProjection();

        // Retrieve the south-west and north-east coordinates of this overlay
        // in LatLngs and covert them to pixel coordinates.
        // We'll use these coordintes to resize the div.
        const sw = overlayProjection.fromLatLngToDivPixel(this.bounds.getSouthWest());
        const ne = overlayProjection.fromLatLngToDivPixel(this.bounds.getNorthEast());

        // Resize the image's div to fit the indicated dimensions
        const div = this.div;
        div.className = 'overlay';
        div.style.left = `${sw.x}px`;
        div.style.top = `${ne.y}px`;
        div.style.width = `${(ne.x - sw.x)}px`;
        div.style.height = `${(sw.y - ne.y)}px`;
      };

      // The onRemove() method will be called automatically from the API
      // If we ever set the overlay's map property to 'null'.
      WELFAREOverlay.prototype.onRemove = function() {
        this.div.parentNode.removeChild(this.div);
        this.div = null;
      };

      const overlay = new WELFAREOverlay(overlayImg);
    },
  };
};
